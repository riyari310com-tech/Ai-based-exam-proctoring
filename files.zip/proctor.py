"""
proctor.py
----------
Run this DURING the exam. It continuously checks the webcam feed and:
  - Confirms the enrolled student is present
  - Flags if no face is found (student left the frame)
  - Flags if more than one face is found (someone else is in the room)
  - Flags if the face doesn't match the enrolled reference (impersonation)

Violations are logged to violations/<student_id>_log.csv with timestamps.

Usage:
    python proctor.py --id student123
"""

import cv2
import face_recognition
import argparse
import os
import csv
from datetime import datetime

MATCH_TOLERANCE = 0.5   # lower = stricter matching (0.4-0.6 is typical)
CHECK_EVERY_N_FRAMES = 5  # face_recognition is slow; don't run it every frame


def load_reference_encoding(student_id: str):
    ref_path = os.path.join("enrolled_faces", f"{student_id}.jpg")
    if not os.path.exists(ref_path):
        raise FileNotFoundError(
            f"No enrollment found for '{student_id}'. Run enroll.py first."
        )
    ref_image = face_recognition.load_image_file(ref_path)
    encodings = face_recognition.face_encodings(ref_image)
    if not encodings:
        raise ValueError("Could not detect a face in the enrolled reference photo.")
    return encodings[0]


def log_violation(student_id: str, reason: str):
    os.makedirs("violations", exist_ok=True)
    log_path = os.path.join("violations", f"{student_id}_log.csv")
    file_exists = os.path.exists(log_path)

    with open(log_path, "a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["timestamp", "violation"])
        writer.writerow([datetime.now().isoformat(timespec="seconds"), reason])

    print(f"[VIOLATION] {reason}")


def run_proctor(student_id: str):
    reference_encoding = load_reference_encoding(student_id)

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("ERROR: Could not open webcam.")
        return

    print("Proctoring started. Press ESC to stop.")
    frame_count = 0
    last_status = "Starting..."

    while True:
        ret, frame = cap.read()
        if not ret:
            print("ERROR: Failed to read from webcam.")
            break

        frame_count += 1

        # Only run the (expensive) face recognition every N frames for performance.
        if frame_count % CHECK_EVERY_N_FRAMES == 0:
            # Resize down for speed, convert BGR (OpenCV) -> RGB (face_recognition)
            small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
            rgb_small = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

            face_locations = face_recognition.face_locations(rgb_small)
            face_encodings = face_recognition.face_encodings(rgb_small, face_locations)

            if len(face_locations) == 0:
                last_status = "NO FACE DETECTED"
                log_violation(student_id, "No face detected in frame")

            elif len(face_locations) > 1:
                last_status = f"MULTIPLE FACES DETECTED ({len(face_locations)})"
                log_violation(student_id, f"Multiple faces detected ({len(face_locations)})")

            else:
                # Exactly one face - check if it matches the enrolled student
                match = face_recognition.compare_faces(
                    [reference_encoding], face_encodings[0], tolerance=MATCH_TOLERANCE
                )[0]
                distance = face_recognition.face_distance(
                    [reference_encoding], face_encodings[0]
                )[0]

                if match:
                    last_status = f"OK - Identity verified (distance={distance:.2f})"
                else:
                    last_status = f"MISMATCH (distance={distance:.2f})"
                    log_violation(student_id, f"Face mismatch (distance={distance:.2f})")

        # Draw status overlay every frame (even ones we didn't re-check)
        color = (0, 255, 0) if "OK" in last_status else (0, 0, 255)
        cv2.putText(frame, last_status, (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    0.6, color, 2)
        cv2.imshow("Exam Proctor - " + student_id, frame)

        if cv2.waitKey(1) & 0xFF == 27:  # ESC
            break

    cap.release()
    cv2.destroyAllWindows()
    print("Proctoring stopped.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--id", required=True, help="Unique student ID (must match enrollment)")
    args = parser.parse_args()
    run_proctor(args.id)
