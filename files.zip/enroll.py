"""
enroll.py
---------
Run this ONCE before the exam to register the student's face.
It opens the webcam, lets the student position their face, and
saves a reference photo to enrolled_faces/<student_id>.jpg

Usage:
    python enroll.py --id student123
"""

import cv2
import argparse
import os

def enroll_face(student_id: str):
    save_dir = "enrolled_faces"
    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, f"{student_id}.jpg")

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("ERROR: Could not open webcam.")
        return

    # Haar cascade just to draw a box and help the student center their face.
    # (Actual matching later uses face_recognition's own detector, which is more accurate.)
    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    )

    print("Position your face in the frame. Press SPACE to capture, ESC to cancel.")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("ERROR: Failed to read from webcam.")
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)

        display = frame.copy()
        for (x, y, w, h) in faces:
            cv2.rectangle(display, (x, y), (x + w, y + h), (0, 255, 0), 2)

        status = f"Faces detected: {len(faces)}  |  SPACE = capture, ESC = cancel"
        cv2.putText(display, status, (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                    0.6, (0, 255, 0), 2)

        cv2.imshow("Enrollment - " + student_id, display)
        key = cv2.waitKey(1) & 0xFF

        if key == 27:  # ESC
            print("Cancelled.")
            break
        elif key == 32:  # SPACE
            if len(faces) == 1:
                cv2.imwrite(save_path, frame)
                print(f"Saved reference photo to {save_path}")
                break
            else:
                print("Need exactly ONE face in frame to enroll. Try again.")

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--id", required=True, help="Unique student ID")
    args = parser.parse_args()
    enroll_face(args.id)
