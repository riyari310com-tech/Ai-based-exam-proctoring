# AI Exam Proctor — Face Verification (Starter)

A beginner-friendly starting point for an AI-based exam proctoring system.
This first version handles **identity verification**: making sure the
person taking the exam is the person who enrolled, and flags if they
leave the frame or someone else joins them.

## How it works

1. **`enroll.py`** — run once before the exam. Opens your webcam,
   captures a clear photo of the student's face, and saves it to
   `enrolled_faces/<student_id>.jpg`.

2. **`proctor.py`** — run during the exam. Continuously checks the
   webcam feed against the enrolled photo:
   - No face in frame → violation logged
   - More than one face in frame → violation logged
   - Face present but doesn't match enrollment → violation logged
   - Match found → status shows "OK"

   All violations are timestamped and saved to
   `violations/<student_id>_log.csv`.

## Setup

```bash
pip install face_recognition opencv-python
```

`face_recognition` depends on `dlib`, which needs a C++ compiler.
- **Mac**: `brew install cmake` first, then pip install.
- **Windows**: easiest via `pip install cmake` then `pip install dlib`,
  or use Anaconda (`conda install -c conda-forge dlib`).
- **Linux**: `sudo apt install cmake` first.

If this gives you install headaches, tell me — MediaPipe is a pure-Python
alternative that avoids dlib entirely and I can swap the code over.

## Usage

```bash
# Step 1: enroll the student (once)
python enroll.py --id student123

# Step 2: run proctoring during the exam
python proctor.py --id student123
```

Press ESC in the webcam window to stop.

## Project structure

```
ai_exam_proctor/
├── enroll.py           # capture reference face
├── proctor.py          # live verification loop
├── enrolled_faces/     # saved reference photos
├── violations/         # CSV logs of flagged events
└── README.md
```

## Where to go next

Once this piece works for you, natural next steps (tell me which
interests you and we'll build it):

- **Gaze / head-pose tracking** — flag if the student keeps looking
  away from the screen (uses MediaPipe Face Mesh).
- **Object detection** — flag phones, books, or extra monitors in
  frame (uses a lightweight YOLO model).
- **Liveness detection** — prevent someone from holding up a photo
  instead of their real face (blink detection, texture analysis).
- **Audio monitoring** — flag conversation or multiple voices.
- **A simple dashboard** — turn the CSV logs into a report a teacher
  can review after the exam.
- **Packaging as a web app** — so it runs in-browser instead of a
  local Python window.

## Tuning notes

- `MATCH_TOLERANCE` in `proctor.py` (default 0.5) controls strictness.
  Lower = stricter (more false "mismatch" flags), higher = looser.
- `CHECK_EVERY_N_FRAMES` (default 5) trades off responsiveness vs.
  CPU load — face matching is the slow part.
